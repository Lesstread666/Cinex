import { createServerClient } from "@supabase/ssr";
import type { Database } from "./database.types";
import { cookies } from "next/headers";


export const createClient = async () => {

    const cookieStore = await cookies();

    return (
        createServerClient<Database>(
            process.env.NEXT_PUBLIC_SUPABASE_URL as string,
            process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY as string,
            {
                cookies: {
                    getAll() {
                        return cookieStore.getAll()
                    },
                    setAll(cookiesToSet) {
                        try {
                            cookiesToSet.forEach(({ name, value, options }) =>
                                cookieStore.set(name, value, options))
                        }
                        catch (error) { error }
                    }
                }
            }
        )
    )
}